# Power BI Sales Dashboard

## Project Overview
This project is an interactive Sales Dashboard built using Power BI. It helps analyze sales performance, profit, customers, and orders through visual reports and KPIs.

## Features
- Total Sales
- Total Profit
- Total Orders
- Total Customers
- Monthly Sales Trends
- Sales by Region
- Sales by Category
- Top Products Analysis

## Tools Used
- Power BI
- Power Query
- DAX
- CSV Dataset

## Author
Bharat Jangir
